class City(object):
    def __init__(self, citycode, cityname):
        self.citycode = citycode
        self.cityName = cityname
