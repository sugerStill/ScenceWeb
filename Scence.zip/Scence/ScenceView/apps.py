from django.apps import AppConfig


class ScenceViewConfig(AppConfig):
    name = 'ScenceView'
