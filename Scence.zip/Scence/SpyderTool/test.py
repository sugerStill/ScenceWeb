# from urllib.parse import urlparse, parse_qs
# import csv
#
# url = "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=2&tn=baiduhome_pg&wd=300200&rsv_spt=1&oq=python%20nonetype&rsv_pq=ddeee0430002a4d3&rsv_t=52bbRWiHUtsbsalW02NaxFrDqU5UVJ5TYaaeofTn0oNP0TZh2BQe7Fyh5viROnY%2BuYJg&rqlang=cn&rsv_enter=1&rsv_sug3=6&rsv_sug1=1&rsv_sug7=100&rsv_sug2=0&inputT=2497&rsv_sug4=2497"
#
# # f = open('/Users/darkmoon/PycharmProjects/Scence/SpyderTool/info.csv','a+',newline='')
# # w = csv.DictWriter(f,fieldnames=None)
# # w.fieldnames=['hi']
# #
# # w.writeheader()
# # w.writerow({"hi":'e'})
# # f.close()
