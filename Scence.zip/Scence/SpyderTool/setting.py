import os

user = 'root'
password = 'lzs87724158'
host = 'localhost'
scencedatabase = 'WebData'
port = 3306
scencefilepath = os.getcwd() + "/DataFiles/ScenceData.csv"
city_file_path = os.getcwd() + "/DataFiles/CityInformation.csv"
trafficdatabase = 'trafficdatabase'
