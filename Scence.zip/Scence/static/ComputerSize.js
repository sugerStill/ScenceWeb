function Computersize() {
    var screen_height = window.screen.height;
    var screen_width = window.screen.width;
    $("body").css({width:screen_width});


}