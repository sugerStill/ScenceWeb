function Animate() {


    $("#navdiv").click(function () {
        $("#navdiv ul li").slideToggle("slow");

    });


}




