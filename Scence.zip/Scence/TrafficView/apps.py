from django.apps import AppConfig


class TrafficviewConfig(AppConfig):
    name = 'TrafficView'
